const bgMusic = document.getElementById('bgMusic');
const volumeButton = document.getElementById('volumeButton');

function showInstructions() {
  window.location.href = "instructions.html";
}

function goToAuthentication() {
  window.location.href = "authentication.html";
}


function toggleVolume() {
  if (bgMusic.paused) {
    bgMusic.play();
    volumeButton.textContent = "🔊";
  } else {
    bgMusic.pause();
    volumeButton.textContent = "🔇";
  }
}